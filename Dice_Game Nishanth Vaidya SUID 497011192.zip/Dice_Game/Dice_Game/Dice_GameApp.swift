//
//  Dice_GameApp.swift
//  Dice_Game
//
//  Created by Nishanth Vaidya on 11/02/25.
//

import SwiftUI

@main
struct Dice_GameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
