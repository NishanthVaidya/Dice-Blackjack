//
//  DiceModel.swift
//  Dice_Game
//
//  Created by Nishanth Vaidya on 12/02/25.
//


import Foundation

struct DiceModel {
    let images = ["dicepic", "Dice1", "Dice2", "Dice3", "Dice4", "Dice5", "Dice6"]
    let images2 = ["dicepic", "Dice2", "Dice3", "Dice4", "Dice5", "Dice6", "Dice1"]
    let images3 = ["dicepic", "Dice2", "Dice5", "Dice6", "Dice3", "Dice4", "Dice1"]
    let images4 = ["dicepic", "Dice4", "Dice5", "Dice2", "Dice3", "Dice6", "Dice1"]
}


