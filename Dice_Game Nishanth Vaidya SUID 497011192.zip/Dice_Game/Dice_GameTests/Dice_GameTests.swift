//
//  Dice_GameTests.swift
//  Dice_GameTests
//
//  Created by Nishanth Vaidya on 11/02/25.
//

import Testing
@testable import Dice_Game

struct Dice_GameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
